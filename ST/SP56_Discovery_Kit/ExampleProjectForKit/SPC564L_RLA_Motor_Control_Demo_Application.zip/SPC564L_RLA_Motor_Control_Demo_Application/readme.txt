This is a placeholder file, you can put here a brief description of your
application or just delete it.
