/*
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ADG License Agreement, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://goo.gl/28pHKW
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

/*
*   @file    USARTParams.h
*   @version BETA 0.9.1
*   @brief   This file contains USART constant parameters definition
*          
*   @details This file contains USART constant parameters definition.
*
*/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_PARAMS_H
#define __USART_PARAMS_H
#include "Parameters conversion.h"

#include "USART_PhysicalLayerCommunication_Class.h"
#include "UIIRQHandlerClass.h"

/* For backward compatibility */
#if (!defined(USART_SPEED))
#define USART_SPEED 115200
#endif


NVIC_USART_INIT_STR

const USART_InitTypeDef USARTInitHW_str = 
{
  USART_SPEED,                    /* USART_BaudRate */
  USART_WordLength_8b,            /* USART_WordLength */
  USART_StopBits_1,               /* USART_StopBits */
  USART_Parity_No,                /* USART_Parity */
  USART_Mode_Rx | USART_Mode_Tx,  /* USART_Mode */
  USART_HardwareFlowControl_None  /* USART_HardwareFlowControl */
};

const USART_InitTypeDef UFCInitHW_str = 
{
  USART_SPEED,                    /* USART_BaudRate */
  USART_WordLength_8b,            /* USART_WordLength */
  USART_StopBits_1,               /* USART_StopBits */
  USART_Parity_No,                /* USART_Parity */
  USART_Mode_Tx,                  /* USART_Mode */
  USART_HardwareFlowControl_None  /* USART_HardwareFlowControl */
};




USARTParams_t USARTParams_str = 
{
  USART,                   /* USART */
  USART_GPIO_REMAP,        /* USART_REMAP GPIO_NoRemap_USART1 or GPIO_Remap_USART1 ... */
  USART_CLK,               /* USART_CLK */
  USART_RX_GPIO_PORT,      /* USART_RxPort */
  USART_RX_GPIO_PIN,       /* USART_RxPin */
  USART_TX_GPIO_PORT,      /* USART_TxPort */
  USART_TX_GPIO_PIN,       /* USART_TxPin */
  UI_IRQ_USART,            /* IRQ Number */
  (USART_InitTypeDef*)(&USARTInitHW_str), /* USART_InitStructure */
  (NVIC_InitTypeDef*)(&NVICInitHW_str)    /* NVIC_InitStructure */
};

UnidirectionalFastComParams_t UFCParams_str =
{
  /* HW Settings */
  USART,                   /* USART */
  USART_GPIO_REMAP,        /* USART_REMAP GPIO_NoRemap_USART1 or GPIO_Remap_USART1 ... */
  USART_CLK,               /* USART_CLK */
  USART_TX_GPIO_PORT,      /* USART_TxPort */
  USART_TX_GPIO_PIN,       /* USART_TxPin */
  UI_IRQ_USART,            /* IRQ Number */
  (USART_InitTypeDef*)(&UFCInitHW_str), /* USART_InitStructure */
  (NVIC_InitTypeDef*)(&NVICInitHW_str), /* NVIC_InitStructure */
  /* Functional settings */
  SERIAL_COM_CHANNEL1, /*!< Code of default variables to be sent Ch1.*/
  SERIAL_COM_CHANNEL2, /*!< Code of default variables to be sent Ch2.*/
  SERIAL_COM_MOTOR,    /*!< Default motor selected. */
  1,                   /*!< Number of bytes transmitted for Ch1 */
  1,                   /*!< Number of bytes transmitted for Ch2 */
  1                    /*!< Number of channel to be transmitted. */
};

FCPParams_t FrameParams_str =
{
  5000,             /* TimeOutRXByte */
  1000,             /* TimeOutTXByte */
  MC_NULL,          /* RXTimeOutEvent */
  MC_NULL           /* TXTimeOutEvent */
};

MCPParams_t MCPParams = 
{
  &FrameParams_str /* pFCPParams */
};

#endif /* __USART_PARAMS_H */
