/*
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ADG License Agreement, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://goo.gl/28pHKW
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

/*
*   @file    FrameCommunicationProtocolClass.c
*   @version BETA 0.9.1
*   @brief   Private implementation for FrameCommunicationProtocol class
*          
*   @details Private implementation for FrameCommunicationProtocol class.
*
*/

/* Includes ------------------------------------------------------------------*/
#include "UserInterfaceClass.h"
#include "MotorControlProtocolClass.h"

#include "FrameCommunicationProtocolClass.h"
#include "FrameCommunicationProtocolPrivate.h"

/* Private function prototypes -----------------------------------------------*/
uint8_t CalcCRC(PFrameData_t pFrame);
uint8_t IsFrameValid(PFrameData_t pFrame);
void FrameTimeOutConfiguration(_CFCP _oFCP);

#ifdef MC_CLASS_DYNAMIC
  #include "stdlib.h" /* Used for dynamic allocation */
#else
  #define MAX_FCP_NUM 1
  static _CFCP_t FCPpool[MAX_FCP_NUM];
  static uint8_t FCP_Allocated = 0;
#endif

/**
  * @brief  Creates an object of the class FrameCommunicationProtocol
  * @param  pSensorParam: Physical Layer parameters
  * @retval oFCP: new Physical Layer object
  */
CFCP FCP_NewObject(pFCPParams_t pFCPParam)
{
  _CFCP _oFCP;
  
  #ifdef MC_CLASS_DYNAMIC
    _oFCP = (_CFCP)calloc(1,sizeof(_CFCP_t));
  #else
    if (FCP_Allocated  < MAX_FCP_NUM)
    {
      _oFCP = &FCPpool[FCP_Allocated++];
    }
    else
    {
      _oFCP = MC_NULL;
    }
  #endif

  FrameTimeOutConfiguration(_oFCP);
  _oFCP->Vars_str.frameTransmitionRX.OnTimeOutByte = pFCPParam->RXTimeOutEvent;
  _oFCP->Vars_str.frameTransmitionTX.OnTimeOutByte = pFCPParam->TXTimeOutEvent;
    
  return ((CFCP)_oFCP);
}

void FCP_Init(CFCP this, CCOM oCOM)
{
  _CFCP _oFCP = ((_CFCP)this);
  _oFCP->Vars_str.oCOM = oCOM;
  COM_SetParent(oCOM, (CFCP)_oFCP);
  
  Frame_ResetTX((CFCP)_oFCP);
  Frame_ResetRX((CFCP)_oFCP);
}

void FCP_SetParent(CFCP this, CMCP_UI oMCP)
{
  ((_CFCP)this)->Vars_str.parent = oMCP;
}

void Frame_ResetTX(CFCP this)
{
  ((_CFCP)this)->Vars_str.frameTransmitionTX.State = FCP_IDLE;
  COM_ResetTX((CCOM)(((_CFCP)this)->Vars_str.oCOM));
}

void Frame_ResetRX(CFCP this)
{
  COM_ResetRX((CCOM)(((_CFCP)this)->Vars_str.oCOM));
  ((_CFCP)this)->Vars_str.frameTransmitionRX.State = FCP_IDLE;
}

uint8_t Frame_Receive(CFCP this)
{
  uint8_t nRet;
  uint8_t i;

  ((_CFCP)this)->Vars_str.frameTransmitionRX.FrameTransferError = FRAME_ERROR_NONE;

  nRet = FRAME_ERROR_TRANSFER_ONGOING;
  if (((_CFCP)this)->Vars_str.frameTransmitionRX.State == FCP_IDLE)
  {
    ((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Code = 0x00;
    ((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Size = 0x00;

    for (i=0; i < FRAME_MAX_BUFFER_LENGTH; i++)
      ((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Buffer[i] = 0x00;

    ((_CFCP)this)->Vars_str.frameTransmitionRX.State = TRANSFERING_HEADER;

    /* Receive the frame */
    COM_ReceiveBuffer((CCOM)(((_CFCP)this)->Vars_str.oCOM),(uint8_t*)&(((_CFCP)this)->Vars_str.frameTransmitionRX).Frame, FRAME_MAX_SIZE); 
    
    nRet = FRAME_ERROR_WAITING_TRANSFER;    
  }
  return nRet;
}

uint8_t Frame_Send(CFCP this, uint8_t code, uint8_t *buffer, uint8_t size)
{
  uint8_t nRet, idx;

  nRet = FRAME_ERROR_TRANSFER_ONGOING;
  if (((_CFCP)this)->Vars_str.frameTransmitionTX.State == FCP_IDLE)
  {
    ((_CFCP)this)->Vars_str.frameTransmitionTX.Frame.Code = code;
    ((_CFCP)this)->Vars_str.frameTransmitionTX.Frame.Size = size;
    
    for (idx=0; idx < size; idx++)
      ((_CFCP)this)->Vars_str.frameTransmitionTX.Frame.Buffer[idx] = buffer[idx];
    
    ((_CFCP)this)->Vars_str.frameTransmitionTX.Frame.Buffer[size] = CalcCRC((PFrameData_t)&(((_CFCP)this)->Vars_str.frameTransmitionTX.Frame));

    ((_CFCP)this)->Vars_str.frameTransmitionTX.State = TRANSFERING_BUFFER;

    /* Send the frame */
    COM_SendBuffer((CCOM)(((_CFCP)this)->Vars_str.oCOM),(uint8_t *)&(((_CFCP)this)->Vars_str.frameTransmitionTX.Frame), ((_CFCP)this)->Vars_str.frameTransmitionTX.Frame.Size + FRAME_HEADER_SIZE + FRAME_CRC_SIZE);
    
    nRet = FRAME_ERROR_WAITING_TRANSFER;
  }
  
  return nRet;
}

/*******************************************************************************
* Function Name  : FrameTimeOutConfiguration
* Description    : This function Configuration for timer7 to manage the timeout
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void FrameTimeOutConfiguration(_CFCP _oFCP)
{  
  _oFCP->Vars_str.frameTransmitionRX.FrameTransferError = FRAME_ERROR_NONE;
  _oFCP->Vars_str.frameTransmitionTX.FrameTransferError = FRAME_ERROR_NONE;
}

/* Private functions */
uint8_t CalcCRC(PFrameData_t pFrame)
{
  uint8_t nCRC = 0;
  uint16_t nSum = 0;
  uint8_t idx;

  if(MC_NULL != pFrame)
  { 
    nSum += pFrame->Code;
    nSum += pFrame->Size;
    for(idx = 0; idx < (pFrame->Size); idx++)
    {
      nSum += pFrame->Buffer[idx];
    }
    nCRC = (uint8_t)(nSum & 0xFF) ; /* Low Byte of nSum */
    nCRC += (uint8_t) (nSum >> 8) ; /* High Byte of nSum */
  }

  return nCRC ;
}

const uint16_t Timeout_none = 0;
const uint16_t Timeout_start = 1;
const uint16_t Timeout_stop = 2;

void* ReceivingFrame(CFCP this, uint16_t size)
{
  void* pRetVal = (void *)(&Timeout_none);
  if (size == 1)  /* First Byte received */
  {
    pRetVal = (void *)(&Timeout_start);
  }
  switch(((_CFCP)this)->Vars_str.frameTransmitionRX.State)
  {
    case TRANSFERING_HEADER:
    {
      if (size == FRAME_HEADER_SIZE)
      {
        /* Receive DATA BUFFER */
        if (((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Size > 0 )
        {
          ((_CFCP)this)->Vars_str.frameTransmitionRX.State = TRANSFERING_BUFFER;
        }
        else
        {
          ((_CFCP)this)->Vars_str.frameTransmitionRX.State = TRANSFERING_CRC;
        }
      }
      break;
    }
    case TRANSFERING_BUFFER:
    {
      /* Receive CRC */
      if ((((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Size + FRAME_HEADER_SIZE) == size)
        ((_CFCP)this)->Vars_str.frameTransmitionRX.State = TRANSFERING_CRC;

      break;
    }
    case TRANSFERING_CRC:
    {
        if (size == (((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Size + FRAME_HEADER_SIZE + FRAME_CRC_SIZE))
        {
          pRetVal = (void *)(&Timeout_stop);
          ((_CFCP)this)->Vars_str.frameTransmitionRX.State = FCP_IDLE;

         ((_CFCP)this)->Vars_str.frameTransmitionRX.FrameTransferError = FRAME_ERROR_INVALID_FRAME;
          if (IsFrameValid((PFrameData_t)&(((_CFCP)this)->Vars_str.frameTransmitionRX.Frame)))
          {
            ((_CFCP)this)->Vars_str.frameTransmitionRX.FrameTransferError = FRAME_ERROR_NONE;

            MCP_ReceivedFrame(((_CFCP)this)->Vars_str.parent,(uint8_t)((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Code, (uint8_t *)((_CFCP)this)->Vars_str.frameTransmitionRX.Frame.Buffer);
          }
          else
          {
            MCP_SendBadCRCMessage(((_CFCP)this)->Vars_str.parent);
          }
        }
        break;
    }
    case FCP_IDLE:
    case TRANSFER_COMPLETE:
    {
        break;
    }
  }
  return pRetVal;
}

void SendingFrame(CFCP this, uint16_t size)
{
    if (size == ((_CFCP)this)->Vars_str.frameTransmitionTX.Frame.Size + FRAME_HEADER_SIZE + FRAME_CRC_SIZE)
      ((_CFCP)this)->Vars_str.frameTransmitionTX.State = FCP_IDLE;

    MCP_SentFrame(((_CFCP)this)->Vars_str.parent);
        
    /* Frame_ResetTX(); */
}

uint8_t IsFrameValid(PFrameData_t pFrame)
{
  if (pFrame)
    return CalcCRC(pFrame) == pFrame->Buffer[pFrame->Size];
  else
    return 0;
}

void FCPTimeOut(CFCP this)
{
  _CFCP _oFCP = ((_CFCP)this);
  _oFCP->Vars_str.frameTransmitionRX.FrameTransferError = FRAME_ERROR_TIME_OUT;
  Frame_ResetRX((CFCP)_oFCP);
}

void FCP_SendOverrunMeassage(CFCP this)
{
  MCP_SendOverrunMeassage(((_CFCP)this)->Vars_str.parent);
}

void FCP_SendTimeoutMeassage(CFCP this)
{
  MCP_SendTimeoutMeassage(((_CFCP)this)->Vars_str.parent);
}
