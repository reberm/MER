/*
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ADG License Agreement, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://goo.gl/28pHKW
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

/*
*   @file    Drive parameters.h
*   @version BETA 0.9.1
*   @brief   This file contains motor parameters
*          
*   @details This file contains motor parameters.
*
*/
 
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DRIVE_PARAMETERS_H
#define __DRIVE_PARAMETERS_H

#include "Reg_eSys_FlexPwm.h"
/******** MAIN AND AUXILIARY SPEED/POSITION SENSOR(S) SETTINGS SECTION ********/

/*** Speed sensor selection ***/
/* #define STATE_OBSERVER_PLL */
/* #define STATE_OBSERVER_CORDIC */
/* #define HFINJECTION */
/* #define ENCODER */
#define HALL_SENSORS
/* #define RESOLVER */

/*** Auxiliary speed measurement selection ***/
/* #define AUX_RESOLVER */
/* #define AUX_STATE_OBSERVER_PLL */
/* #define AUX_STATE_OBSERVER_CORDIC */
/* #define AUX_HFINJECTION */
/* #define AUX_ENCODER */
/* #define AUX_HALL_SENSORS */

/*** Drives number selection ***/
#define SINGLEDRIVE
/* #define DUALDRIVE */

/*** Speed measurement settings ***/
#define MAX_APPLICATION_SPEED           10300 /*!< rpm, mechanical */
#define MIN_APPLICATION_SPEED           0 /*!< rpm, mechanical,  
                                                           absolute value */
#define MEAS_ERRORS_BEFORE_FAULTS       255 /*!< Number of speed  
                                                             measurement errors before 
                                                             main sensor goes in fault */

/****** Encoder ************/
/****** Default: Quadrature Encoder parameters are the ones of the main sensor ******/
#define ENC_MEAS_ERRORS_BEFORE_FAULTS   255 /*!< Number of failed   
                                                        derived class specific speed 
                                                        measurements before main sensor  
                                                        goes in fault */
#define ENC_ICx_FILTER                  94 /*!< Duration of input  
                                                           capture filter in CPU clock   
                                                           cycles in case of   
                                                           quadrature encoder main 
                                                           or auxiliary sensors in use */
#define ENC_INVERT_SPEED                DISABLE  /*!< To be enabled for  
                                                            encoder (main or aux) if  
                                                            measured speed is opposite 
                                                            to real one */
#define ENC_AVERAGING_FIFO_DEPTH        16 /*!< depth of the FIFO used to 
                                                              average mechanical speed in 
                                                              0.1Hz resolution */

/****** Hall sensors ************/
/****** Hall Sensor is the main sensor ******/
#define HALL_MEAS_ERRORS_BEFORE_FAULTS  255 /*!< Number of failed   
                                                           derived class specific speed 
                                                           measurements before main sensor  
                                                           goes in fault */
#define HALL_ICx_FILTER                 176 /*!< Duration of input  
                                                           capture filter in CPU clock   
                                                           cycles in case of Hall sensors  
                                                           main or auxiliary sensors
                                                           in use */
#define HALL_AVERAGING_FIFO_DEPTH        20 /*!< depth of the FIFO used to 
                                                           average mechanical speed in 
                                                           0.1Hz resolution */

/****** Resolver ************/
/****** Default: Resolver parameters are the ones of the main sensor ******/
#define RES_SIGN_FREQ 10000 /* Hz */

#define RES_SIGN_FREQ_TICKS (uint16_t)(ADV_eTIMER_CLK_MHz*\
                                      (unsigned long long)1000000u/((uint16_t)(RES_SIGN_FREQ)))
                                      
#define RES_FILT_SHIFT_TICKS 600U  

/* Enable LOOKUP Table if defined */
/* #define RES_ANGLE_CALC_LOOKUP_TABLE */
/* #define RES_SIN_PH_EN */

#define  MEDIUM_FREQUENCY_TASK_RATE 500  /*!< Frequency (Hz) at which motor speed is to 
                                                                   be computed. It must be equal to the frequency
                                                                   at which function SPD_CalcAvrgMecSpeed01Hz
                                                                   is called.*/

/* Resolver parameters editable only in Advanced Mode */
#define  RES_PHASE_SHIFT                      0        /* Define here in s16degree the electrical phase shift
                                                                                  between the Resolver Channel A and
                                                                                  the Bemf induced on phase A.*/
#define  RES_SIN_PHASE_CH_B                   887          /* Sine of channel B phase w.r.t. channel A multiplied by 1024 */
#define  RES_COS_PHASE_CH_B                   -512          /* Cosine of channel B phase w.r.t. channel A multiplied by 1024 */
#define  RES_ANGLE_READING_TYPE               RES_ELECTRICAL_DEGREES   /* Resolver reading angle type */
#define  RES_POLE2MOTOR_DEGREE_MULTIPLIER     500          /* Multiplier between resolver pole pair and motor pole pair */
#define  RES_MIN_ADC_CH_A                     240            /* Minimum value readable from the ADC channel A */
#define  RES_MAX_ADC_CH_A                     870            /* Maximum value readable from the ADC channel A */
#define  RES_MIN_ADC_CH_B                     236            /* Minimum value readable from the ADC channel B */
#define  RES_MAX_ADC_CH_B                     831            /* Maximum value readable from the ADC channel B */

/****** State Observer + PLL ************/
/****** Default: State Observer + PLL parameters are the ones of the main sensor ******/
#define VARIANCE_THRESHOLD               0.062 /*!<Maximum accepted 
                                                            variance on speed 
                                                            estimates (percentage) */
/* State observer scaling factors F1 */                    
#define F1                               1024
#define F2                               16384

/* State observer constants */
#define GAIN1                            -1357
#define GAIN2                            12292
/* Only in case PLL is used, PLL gains */
#define PLL_KP_GAIN                      274
#define PLL_KI_GAIN                      10

#define OBS_MEAS_ERRORS_BEFORE_FAULTS    255  /*!< Number of consecutive errors   
                                                           on variance test before a speed 
                                                           feedback error is reported */
#define STO_FIFO_DEPTH_DPP               64  /*!< Depth of the FIFO used  
                                                            to average mechanical speed  
                                                            in dpp format */
#define STO_FIFO_DEPTH_01HZ              64  /*!< Depth of the FIFO used  
                                                            to average mechanical speed  
                                                            in dpp format */
#define BEMF_CONSISTENCY_TOL             64   /* Parameter for B-emf 
                                                            amplitude-speed consistency */
#define BEMF_CONSISTENCY_GAIN            64   /* Parameter for B-emf 
                                                           amplitude-speed consistency */

/****** State Observer + Cordic ************/
/****** Default: State Observer + Cordic parameters are the ones of the main sensor ******/
#define CORD_VARIANCE_THRESHOLD          4  /*!<Maxiumum accepted 
                                                            variance on speed 
                                                            estimates (percentage) */                                                                                                                
#define CORD_F1                          1024
#define CORD_F2                          16384

/* State observer constants */
#define CORD_GAIN1                       -1357
#define CORD_GAIN2                       12292


#define CORD_MEAS_ERRORS_BEFORE_FAULTS   255  /*!< Number of consecutive errors   
                                                           on variance test before a speed 
                                                           feedback error is reported */
#define CORD_FIFO_DEPTH_DPP              64  /*!< Depth of the FIFO used  
                                                            to average mechanical speed  
                                                            in dpp format */
#define CORD_FIFO_DEPTH_01HZ             64  /*!< Depth of the FIFO used  
                                                           to average mechanical speed  
                                                           in dpp format */        
#define CORD_MAX_ACCEL_DPPP              30  /*!< Maximum instantaneous 
                                                              electrical acceleration (dpp 
                                                              per control period) */
#define CORD_BEMF_CONSISTENCY_TOL        64  /* Parameter for B-emf 
                                                           amplitude-speed consistency */
#define CORD_BEMF_CONSISTENCY_GAIN       64  /* Parameter for B-emf 
                                                          amplitude-speed consistency */

/****** HFI ************/
#define HFI_FREQUENCY                    400
#define HFI_AMPLITUDE                    25

#define HFI_PID_KP_DEFAULT               800
#define HFI_PID_KI_DEFAULT               400
#define HFI_PID_KPDIV                    16384
#define HFI_PID_KIDIV                    32768

#define HFI_IDH_DELAY                    32400

#define HFI_PLL_KP_DEFAULT               0.00060
#define HFI_PLL_KI_DEFAULT               0.00400

#define HFI_NOTCH_0_COEFF                0.969619
#define HFI_NOTCH_1_COEFF                -1.923946
#define HFI_NOTCH_2_COEFF                0.969619
#define HFI_NOTCH_3_COEFF                1.923946
#define HFI_NOTCH_4_COEFF                -0.939237

#define HFI_LP_0_COEFF                   0.00597
#define HFI_LP_1_COEFF                   0.011941
#define HFI_LP_2_COEFF                   0.00597
#define HFI_LP_3_COEFF                   1.769837
#define HFI_LP_4_COEFF                   -0.793719

#define HFI_HP_0_COEFF                   0.939693
#define HFI_HP_1_COEFF                   -1.879386
#define HFI_HP_2_COEFF                   0.939693
#define HFI_HP_3_COEFF                   1.875746
#define HFI_HP_4_COEFF                   -0.883026

#define HFI_DC_0_COEFF                   0.00146
#define HFI_DC_1_COEFF                   0.002921
#define HFI_DC_2_COEFF                   0.00146
#define HFI_DC_3_COEFF                   1.889033
#define HFI_DC_4_COEFF                   -0.894874

#define HFI_MINIMUM_SPEED_RPM            402
#define HFI_SPD_BUFFER_DEPTH_01HZ        64
#define HFI_LOCKFREQ                     33
#define HFI_SCANROTATIONSNO              3
#define HFI_WAITBEFORESN                 6
#define HFI_WAITAFTERNS                  4
#define HFI_HIFRAMPLSCAN                 25
#define HFI_NSMAXDETPOINTS               20
#define HFI_NSDETPOINTSSKIP              10
#define HFI_DEBUG_MODE                   FALSE

#define HFI_STO_RPM_TH                   OBS_MINIMUM_SPEED_RPM
#define STO_HFI_RPM_TH                   460
#define HFI_RESTART_RPM_TH               (((HFI_STO_RPM_TH) + (STO_HFI_RPM_TH))/2)
#define HFI_NS_MIN_SAT_DIFF              0

#define HFI_REVERT_DIRECTION             FALSE
#define HFI_WAITTRACK                    20
#define HFI_WAITSYNCH                    20
#define HFI_STEPANGLE                    3640
#define HFI_MAXANGLEDIFF                 3640
#define HFI_RESTARTTIMESEC               0.1

/**************************    DRIVE SETTINGS SECTION   **********************/
/* PWM generation and current reading */
#define SPC5_INIT                        TRUE
#define PWM_FREQUENCY                    20000

 /************************* PWM FOC UPDATE    ***************************************************/
/* PWM duty cycle updated (PWM MRS)                                                            */
/* FLEXPWM_CTRL_LDFQ_EACH1-FLEXPWM_CTRL_LDFQ_EACH16                                            */
/* i.e. FLEXPWM_CTRL_LDFQ_EACH2: the new PWM duty cycles are updates every two PWM periods.    */
/* This parameter must be equal to PWMLoadFreq parameter of ICS_Params_t structure (ICS class) */
/* in SystemNDriveParams.h                                                                     */
#define FLEXPWM_LDFQ FLEXPWM_CTRL_LDFQ_EACH1
#define PWM_FOC_UPDATE ((FLEXPWM_LDFQ >> 12) + 1U)
#define eTIMER_CLOCK_DIVIDER  1
#define ADV_eTIMER_CLK_MHz    120uL/eTIMER_CLOCK_DIVIDER

#define LOW_SIDE_SIGNALS_ENABLING        LS_PWM_TIMER
#define SW_DEADTIME_NS                   (156) /*!< Dead-time to be inserted  
                                                           by FW, only if low side 
                                                           signals are enabled */
#define HIGH_SIDE_IDLE_STATE              TURN_OFF /*!< TURN_OFF, TURN_ON */
#define LOW_SIDE_IDLE_STATE               TURN_ON /*!< TURN_OFF, TURN_ON */
                                                                                          
/* Torque and flux regulation loops */
#define REGULATION_EXECUTION_RATE     1    /*!< FOC execution rate in 
                                                           number of PWM cycles */  
/* Gains values for torque and flux control loops */
#define PID_TORQUE_KP_DEFAULT         845       
#define PID_TORQUE_KI_DEFAULT         197
#define PID_TORQUE_KD_DEFAULT         100
#define PID_FLUX_KP_DEFAULT           845
#define PID_FLUX_KI_DEFAULT           197
#define PID_FLUX_KD_DEFAULT           100

/* Torque/Flux control loop gains dividers*/
#define TF_KPDIV                      16384
#define TF_KIDIV                      16384
#define TF_KDDIV                      8192
#define TFDIFFERENTIAL_TERM_ENABLING  DISABLE

/* Speed control loop */ 
#define SPEED_LOOP_FREQUENCY_HZ       500 /*!<Execution rate of speed   
                                                      regulation loop (Hz) */
#define PID_SPEED_KP_DEFAULT          1000
#define PID_SPEED_KI_DEFAULT          700
#define PID_SPEED_KD_DEFAULT          0

/* Speed PID parameter dividers */
#define SP_KPDIV                      16
#define SP_KIDIV                      256
#define SP_KDDIV                      16
#define SPD_DIFFERENTIAL_TERM_ENABLING DISABLE

/* Default settings */
#define DEFAULT_CONTROL_MODE           STC_SPEED_MODE /*!< STC_TORQUE_MODE or 
                                                        STC_SPEED_MODE */  
#define DEFAULT_TARGET_SPEED_RPM       1500
#define DEFAULT_TORQUE_COMPONENT       0
#define DEFAULT_FLUX_COMPONENT         0

/**************************    FIRMWARE PROTECTIONS SECTION   *****************/

#define OV_VOLTAGE_PROT_ENABLING        DISABLE /*!< Over voltage protection disabled */
#define UV_VOLTAGE_PROT_ENABLING        DISABLE /*!< Under voltage protection disabled */
#define OV_VOLTAGE_THRESHOLD_V          (14U) /*!< Over-voltage threshold */
#define UD_VOLTAGE_THRESHOLD_V          (10U) /*!< Under-voltage threshold */

#define ON_OVER_VOLTAGE                 TURN_OFF_PWM /*!< TURN_OFF_PWM, 
                                                          TURN_ON_R_BRAKE or 
                                                          TURN_ON_LOW_SIDES */
#define R_BRAKE_SWITCH_OFF_THRES_V      10

#define OV_TEMPERATURE_PROT_ENABLING    DISABLE
#define OV_TEMPERATURE_THRESHOLD_C      70 /*!< Celsius degrees */
#define OV_TEMPERATURE_HYSTERESIS_C     10 /*!< Celsius degrees */

#define HW_OV_CURRENT_PROT_BYPASS       DISABLE /*!< In case ON_OVER_VOLTAGE  
                                                          is set to TURN_ON_LOW_SIDES
                                                          this feature may be used to
                                                          bypass HW over-current
                                                          protection (if supported by 
                                                          power stage) */
/******************************   START-UP PARAMETERS   **********************/
/* Encoder alignment */
#define ALIGNMENT_DURATION              700    /*!< milliseconds */
#define ALIGNMENT_ANGLE_DEG             90      /*!< degrees [0...359] */
#define FINAL_I_ALIGNMENT               1548    /*!< s16A */
/* With ALIGNMENT_ANGLE_DEG equal to 90 degrees final alignment */
/* phase current = (FINAL_I_ALIGNMENT * 1.65/ Av)/(32767 * Rshunt) */
/* being Av the voltage gain between Rshunt and A/D input */


/* Sensor-less rev-up sequence (BASIC)*/
#define STARTING_ANGLE_DEG             90  /*!< degrees [0...359] */
/* Phase 1 */
#define PHASE1_DURATION                1000 /*milliseconds */
#define PHASE1_FINAL_SPEED_RPM         0 /* rpm */
#define PHASE1_FINAL_CURRENT           5560    /*!< s16A */
/* Phase 2 */
#define PHASE2_DURATION                0 /*milliseconds */
#define PHASE2_FINAL_SPEED_RPM         0 /* rpm */
#define PHASE2_FINAL_CURRENT           5560    /*!< s16A */
/* Phase 3 */
#define PHASE3_DURATION                500 /*milliseconds */
#define PHASE3_FINAL_SPEED_RPM         667 /* rpm */
#define PHASE3_FINAL_CURRENT           6354    /*!< s16A */
/* Phase 4 */
#define PHASE4_DURATION                1000 /*milliseconds */
#define PHASE4_FINAL_SPEED_RPM         2000 /* rpm */
#define PHASE4_FINAL_CURRENT           6354    /*!< s16A */
/* Phase 5 */
#define PHASE5_DURATION                0 /* milliseconds */
#define PHASE5_FINAL_SPEED_RPM         2000 /* rpm */
#define PHASE5_FINAL_CURRENT           6354    /*!< s16A */

#define ENABLE_SL_ALGO_FROM_PHASE      3
                                                         
/* Observer start-up output conditions */
#define OBS_MINIMUM_SPEED_RPM          450
#define NB_CONSECUTIVE_TESTS           2 /* corresponding to 
                                                         former NB_CONSECUTIVE_TESTS/
                                                         (TF_REGULATION_RATE/
                                                         MEDIUM_FREQUENCY_TASK_RATE) */
#define SPEED_BAND_UPPER_LIMIT         17 /*!< It expresses how much 
                                                            estimated speed can exceed 
                                                            forced stator electrical 
                                                            without being considered wrong. 
                                                            In 1/16 of forced speed */
#define SPEED_BAND_LOWER_LIMIT         15  /*!< It expresses how much 
                                                             estimated speed can be below 
                                                             forced stator electrical 
                                                             without being considered wrong. 
                                                             In 1/16 of forced speed */
#define TRANSITION_DURATION            100  /* Switch over duration, ms */
/******************************   ADDITIONAL FEATURES   **********************/
#define BUS_VOLTAGE_READING            DISABLE /*!< Bus voltage sensing disabled */

#define TEMPERATURE_READING            DISABLE

#define  OPEN_LOOP_FOC                 DISABLE   /*!< ENABLE for open loop */
#define  OPEN_LOOP_VOLTAGE_d           6000      /*!< Three Phase voltage amplitude
                                                      in s16 format */
#define  OPEN_LOOP_SPEED_RPM           100       /*!< Final forced speed in rpm */
#define  OPEN_LOOP_SPEED_RAMP_DURATION_MS  1000  /*!< 0-to-Final speed ramp duration  */      
#define  OPEN_LOOP_VF                  FALSE     /*!< TRUE to enable V/F mode */
#define  OPEN_LOOP_K                   44        /*! Slope of V/F curve expressed in s16 Voltage for 
                                                     each 0.1Hz of mecchanical frequency increment. */
#define  OPEN_LOOP_OFF                 4400      /*! Offset of V/F curve expressed in s16 Voltage 
                                                     applied when frequency is zero. */

/* Flux Weakening parameters */
#define  FLUX_WEAKENING_ENABLING       DISABLE
#define  FW_VOLTAGE_REF                985 /*!<Vs reference, tenth 
                                                        of a percent */
#define  FW_KP_GAIN                    3000 /*!< Default Kp gain */
#define  FW_KI_GAIN                    5000 /*!< Default Ki gain */
#define  FW_KPDIV                      32768      
                                                /*!< Kp gain divisor.If FULL_MISRA_C_COMPLIANCY
                                                is not defined the divisor is implemented through       
                                                algebrical right shifts to speed up PIs execution. 
                                                Only in this case this parameter specifies the 
                                                number of right shifts to be executed */
#define  FW_KIDIV                      32768
                                                /*!< Ki gain divisor.If FULL_MISRA_C_COMPLIANCY
                                                is not defined the divisor is implemented through       
                                                algebrical right shifts to speed up PIs execution. 
                                                Only in this case this parameter specifies the 
                                                number of right shifts to be executed */
/*  Feed-forward parameters */
#define FEED_FORWARD_CURRENT_REG_ENABLING   DISABLE
#define CONSTANT1_Q                    123532
#define CONSTANT1_D                    123532
#define CONSTANT2_QD                   5837

/*  Maximum Torque Per Ampere strategy parameters */
#define MTPA_ENABLING                  DISABLE
#define IQMAX                          6354
#define SEGDIV                         0
#define ANGC                           {0,0,0,0,0,0,0,0}
#define OFST                           {0,0,0,0,0,0,0,0}

/* Inrush current limiter parameters: Additional Features*/
#define INRUSH_CURRLIMIT_ENABLING        DISABLE
#define INRUSH_CURRLIMIT_AT_POWER_ON     INACTIVE   /* ACTIVE or INACTIVE */
#define INRUSH_CURRLIMIT_CHANGE_AFTER_MS 1000       /* milliseconds */

/******************************** DEBUG ADD-ONs *******************************/
#define LCD_JOYSTICK_FUNCTIONALITY       DISABLE
#define LCD_MODE                         LCD_FULL
#define START_STOP_BTN                   DISABLE

#define CAN_COMMUNICATION                DISABLE
#define CAN_MAX_MSG_LENGTH               8U
#define CAN_TX_MSG_ID_START              16U
#define CAN_BR_SELECTION                 CAN_250_KBPS

#define SERIAL_COMMUNICATION             ENABLE
#define SERIAL_COM_MODE                  COM_BIDIRECTIONAL
#define SERIAL_COM_CHANNEL1              MC_PROTOCOL_REG_I_A
#define SERIAL_COM_CHANNEL2              MC_PROTOCOL_REG_I_A
#define SERIAL_COM_MOTOR                 0

/******************************** PFC ENABLING ********************************/
/* #define PFC_ENABLED to enable the PFC */ 

#endif /*__DRIVE_PARAMETERS_H*/
